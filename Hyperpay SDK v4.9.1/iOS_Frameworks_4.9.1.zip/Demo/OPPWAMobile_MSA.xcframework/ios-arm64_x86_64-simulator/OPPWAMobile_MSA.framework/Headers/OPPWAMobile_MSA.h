//
// Copyright (c) $$year$$ by ACI Worldwide, Inc.
// All rights reserved.
//
// This software is the confidential and proprietary information
// of ACI Worldwide Inc ("Confidential Information"). You shall
// not disclose such Confidential Information and shall use it
// only in accordance with the terms of the license agreement
// you entered with ACI Worldwide Inc.
//

#import <Foundation/Foundation.h>

//! Project version number for OPPWAMobile_MSA.
FOUNDATION_EXPORT double OPPWAMobile_MSAVersionNumber;

//! Project version string for OPPWAMobile_MSA.
FOUNDATION_EXPORT const unsigned char OPPWAMobile_MSAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OPPWAMobile_MSA/PublicHeader.h>


